# bone-segmentation
group model training for femur segmentation
